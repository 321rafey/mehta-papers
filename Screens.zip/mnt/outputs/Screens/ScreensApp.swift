// ScreensApp.swift
// Screens
//
// App entry point. SwiftUI lifecycle — no AppDelegate needed for the demo.
//
// ──────────────────────────────────────────────────────────────────────────
// GOOGLE SIGN-IN NOTE
// When you add the GoogleSignIn-iOS package (see SETUP_GUIDE.md), you will
// need to add an AppDelegate to handle the OAuth redirect URL. Uncomment the
// AppDelegate block below and the @UIApplicationDelegateAdaptor line once
// the package is installed.
// ──────────────────────────────────────────────────────────────────────────

import SwiftUI

@main
struct ScreensApp: App {

    // Uncomment after adding GoogleSignIn-iOS via SPM:
    // @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
                // Hide the default navigation bar globally
                .navigationBarHidden(true)
        }
    }
}

// MARK: - AppDelegate (uncomment when GoogleSignIn SDK is added)
//
// import GoogleSignIn
//
// class AppDelegate: NSObject, UIApplicationDelegate {
//     func application(
//         _ app: UIApplication,
//         open url: URL,
//         options: [UIApplication.OpenURLOptionsKey: Any] = [:]
//     ) -> Bool {
//         return GIDSignIn.sharedInstance.handle(url)
//     }
// }
