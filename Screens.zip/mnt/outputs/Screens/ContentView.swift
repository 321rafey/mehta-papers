// ContentView.swift
// Screens
//
// Root navigation controller.
// Instead of a NavigationStack (which adds a nav bar), we use a simple
// @State enum + ZStack so every transition is under our full control.

import SwiftUI

// MARK: - App Screen Enum
/// Defines every top-level screen in the app.
/// Add new cases here as you build out more features.
enum AppScreen {
    case splash
    case onboarding
    case login
    case signUp
    // Future screens — add here:
    // case home
    // case forgotPassword
}

// MARK: - Content View
struct ContentView: View {

    /// The single source of truth for which screen is visible.
    @State private var currentScreen: AppScreen = .splash

    var body: some View {
        ZStack {
            switch currentScreen {

            case .splash:
                SplashView(currentScreen: $currentScreen)
                    .transition(.opacity)

            case .onboarding:
                OnboardingView(currentScreen: $currentScreen)
                    .transition(.opacity)

            case .login:
                LoginView(currentScreen: $currentScreen)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing),
                        removal:   .move(edge: .leading)
                    ))

            case .signUp:
                SignUpView(currentScreen: $currentScreen)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing),
                        removal:   .move(edge: .leading)
                    ))
            }
        }
        // Smooth animated transitions whenever currentScreen changes
        .animation(.easeInOut(duration: 0.30), value: currentScreen)
        // Remove any system-injected background
        .background(Color.white)
        .ignoresSafeArea()
    }
}

// MARK: - Preview
#Preview {
    ContentView()
}
