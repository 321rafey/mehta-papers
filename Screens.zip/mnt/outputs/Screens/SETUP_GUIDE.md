# Screens — Xcode Setup Guide

Follow these steps in order to get a fully running demo of all four screens.

---

## 1. Create the Xcode Project

1. Open **Xcode → File → New → Project**
2. Choose **iOS → App**
3. Fill in:
   - **Product Name:** `Screens`
   - **Interface:** `SwiftUI`
   - **Language:** `Swift`
   - **Minimum Deployments:** `iOS 16.0`
4. Choose a folder to save it and click **Create**

---

## 2. Add the Swift Files

Delete the default `ContentView.swift` Xcode created, then drag in **all files from this folder** while keeping the same subfolder structure:

```
Screens/                          ← your Xcode project folder
├── ScreensApp.swift
├── ContentView.swift
├── Helpers/
│   └── Theme.swift
├── Components/
│   ├── LogoView.swift
│   └── SharedComponents.swift
├── Views/
│   ├── SplashView.swift
│   ├── OnboardingView.swift
│   └── Auth/
│       ├── SignUpView.swift
│       └── LoginView.swift
└── ViewModels/
    └── AuthViewModel.swift
```

**How to drag files in Xcode:**
- In the Project Navigator (left panel), right-click the `Screens` group → **Add Files to "Screens"…**
- Select all files, make sure **"Copy items if needed"** is checked, and **"Create groups"** is selected.

---

## 3. Add Icon Assets (Required for Social Buttons)

The Google and Facebook buttons reference two image assets by name.
You need to add them to `Assets.xcassets`:

1. Download the official icons:
   - Google: https://developers.google.com/identity/branding-guidelines (download the "G" logo PNG)
   - Facebook: https://developers.facebook.com/docs/facebook-login/userexperience/#buttondesign

2. In Xcode, open `Assets.xcassets`
3. Right-click → **New Image Set** → name it exactly **`google_icon`**
4. Drag the Google PNG into the `1x`, `2x`, or `3x` slot
5. Repeat for **`facebook_icon`**

> **Note:** Until you add these, the buttons will show placeholder SF Symbols (a red G and blue F) — the app will still run fine.

---

## 4. Optional: Add Google Sign-In SDK

> Only needed when you're ready to wire up real Google OAuth.

1. In Xcode: **File → Add Package Dependencies…**
2. Paste the URL: `https://github.com/google/GoogleSignIn-iOS`
3. Click **Add Package**
4. Select the **`GoogleSignIn`** product → **Add to Target: Screens**

**After adding the package:**
- Open `ScreensApp.swift` and **uncomment** the `AppDelegate` class and the `@UIApplicationDelegateAdaptor` line
- In `Info.plist` (right-click → Open As → Source Code), add:

```xml
<key>GIDClientID</key>
<string>YOUR_GOOGLE_CLIENT_ID_HERE</string>

<key>CFBundleURLTypes</key>
<array>
  <dict>
    <key>CFBundleURLSchemes</key>
    <array>
      <string>com.googleusercontent.apps.YOUR_CLIENT_ID</string>
    </array>
  </dict>
</array>
```

- In `AuthViewModel.swift`, find `signInWithGoogle()` and follow the STEP comments to uncomment the real SDK code.

---

## 5. Optional: Add Facebook Login SDK

> Only needed when you're ready to wire up real Facebook OAuth.

1. In Xcode: **File → Add Package Dependencies…**
2. Paste the URL: `https://github.com/facebook/facebook-ios-sdk`
3. Click **Add Package**
4. Select **`FacebookLogin`** → **Add to Target: Screens**

**After adding the package:**
- In `Info.plist`, add:

```xml
<key>FacebookAppID</key>
<string>YOUR_FACEBOOK_APP_ID</string>

<key>FacebookClientToken</key>
<string>YOUR_FACEBOOK_CLIENT_TOKEN</string>

<key>FacebookDisplayName</key>
<string>Screens</string>

<key>LSApplicationQueriesSchemes</key>
<array>
  <string>fbapi</string>
  <string>fb-messenger-share-api</string>
</array>

<key>CFBundleURLTypes</key>
<array>
  <dict>
    <key>CFBundleURLSchemes</key>
    <array>
      <string>fbYOUR_FACEBOOK_APP_ID</string>
    </array>
  </dict>
</array>
```

- In `AuthViewModel.swift`, find `signInWithFacebook()` and follow the STEP comments.

---

## 6. Run the App

1. Select any **iPhone simulator** from the toolbar (iPhone 15 Pro recommended)
2. Press **⌘R** to build and run
3. You should see:
   - Splash screen → logo animates in → auto-navigates after 2 sec
   - Onboarding carousel with 4 swipeable pages + animated dots
   - Login and Sign Up screens fully interactive

---

## File Roles (Quick Reference)

| File | Purpose |
|------|---------|
| `ScreensApp.swift` | App entry point |
| `ContentView.swift` | Root screen switcher (no navigation bar) |
| `Theme.swift` | All colors, gradients, and the `Color(hex:)` extension |
| `LogoView.swift` | Geometric logo drawn entirely in SwiftUI (no image needed) |
| `SharedComponents.swift` | Reusable: SocialButton, AuthTextField, CheckboxView, etc. |
| `SplashView.swift` | Animated logo on gradient, auto-transitions to onboarding |
| `OnboardingView.swift` | 4-page swipeable carousel with dots + Sign Up / Login buttons |
| `SignUpView.swift` | Registration screen |
| `LoginView.swift` | Login screen |
| `AuthViewModel.swift` | Auth logic — stubs now, swap in real SDK calls later |

---

## What's Stubbed vs Real

| Feature | Status | Notes |
|---------|--------|-------|
| All 4 screens / navigation | ✅ Ready | Fully built |
| Logo (geometric) | ✅ Ready | Pure SwiftUI, no image needed |
| Form fields + validation | ✅ Ready | Basic email validation included |
| Email sign-up / login | 🔧 Stub | Prints to console; see AuthViewModel TODOs |
| Google Sign-In | 🔧 Stub | Uncomment after adding package (Step 4) |
| Facebook Login | 🔧 Stub | Uncomment after adding package (Step 5) |
