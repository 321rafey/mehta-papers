// LogoView.swift
// Screens
//
// Recreates the geometric logo from the screenshots entirely in SwiftUI —
// two right-pointing triangles ("play button" shapes) side-by-side,
// with the right one having a folded top-right corner (paper-fold effect).
// No image asset required; scales to any size.

import SwiftUI

// MARK: - Logo View
struct LogoView: View {

    /// Overall bounding size of the logo mark.
    var size: CGFloat = 100

    var body: some View {
        ZStack {
            // ── Left triangle ────────────────────────────────────────────
            TriangleShape()
                .fill(
                    LinearGradient(
                        colors: [.white, Color.white.opacity(0.72)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: size * 0.42, height: size * 0.65)
                .shadow(color: .black.opacity(0.13), radius: 6, x: 2, y: 4)
                .offset(x: -size * 0.20)

            // ── Right triangle (paper-fold corner at top-right) ──────────
            FoldedTriangleShape(foldRatio: 0.30)
                .fill(
                    LinearGradient(
                        colors: [Color.white.opacity(0.95), Color.white.opacity(0.62)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: size * 0.42, height: size * 0.65)
                .shadow(color: .black.opacity(0.10), radius: 6, x: 2, y: 4)
                .offset(x: size * 0.20)

            // ── Fold crease overlay (small lighter triangle in corner) ───
            FoldCreaseShape(foldRatio: 0.30)
                .fill(Color.white.opacity(0.55))
                .frame(width: size * 0.42, height: size * 0.65)
                .offset(x: size * 0.20)
        }
        .frame(width: size, height: size)
    }
}

// MARK: - Triangle Shape
/// A right-pointing isoceles triangle (standard "play button").
struct TriangleShape: Shape {
    func path(in rect: CGRect) -> Path {
        Path { p in
            p.move(to:    CGPoint(x: rect.minX, y: rect.minY))
            p.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
            p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
            p.closeSubpath()
        }
    }
}

// MARK: - Folded Triangle Shape
/// Right-pointing triangle with a rectangular notch cut from the top-right
/// corner, simulating a folded page corner.
struct FoldedTriangleShape: Shape {
    /// Fold size relative to the shape's width (0 = no fold, 1 = full width).
    var foldRatio: CGFloat = 0.28

    func path(in rect: CGRect) -> Path {
        let fw = rect.width  * foldRatio        // fold width
        let fh = rect.height * foldRatio * 0.55 // fold height

        return Path { p in
            p.move(to:    CGPoint(x: rect.minX, y: rect.minY))           // top-left
            p.addLine(to: CGPoint(x: rect.maxX - fw, y: rect.minY))      // top, before fold
            p.addLine(to: CGPoint(x: rect.maxX - fw, y: rect.minY + fh)) // fold edge down
            p.addLine(to: CGPoint(x: rect.maxX,      y: rect.midY))      // tip of triangle
            p.addLine(to: CGPoint(x: rect.minX,      y: rect.maxY))      // bottom-left
            p.closeSubpath()
        }
    }
}

// MARK: - Fold Crease Shape
/// The small lighter triangle that fills the folded corner area,
/// giving it a realistic paper-fold appearance.
struct FoldCreaseShape: Shape {
    var foldRatio: CGFloat = 0.28

    func path(in rect: CGRect) -> Path {
        let fw = rect.width  * foldRatio
        let fh = rect.height * foldRatio * 0.55

        return Path { p in
            p.move(to:    CGPoint(x: rect.maxX - fw, y: rect.minY))      // top of fold
            p.addLine(to: CGPoint(x: rect.maxX,      y: rect.minY))      // outer corner
            p.addLine(to: CGPoint(x: rect.maxX - fw, y: rect.minY + fh)) // bottom of fold
            p.closeSubpath()
        }
    }
}

// MARK: - Preview
#Preview {
    ZStack {
        Theme.appGradient.ignoresSafeArea()
        VStack(spacing: 40) {
            LogoView(size: 120)
            LogoView(size: 60)
            LogoView(size: 40)
        }
    }
}
