// SharedComponents.swift
// Screens
//
// Reusable UI building blocks used across multiple screens.
// Keeping them here avoids duplication and makes style changes easy.

import SwiftUI

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: Social Login Button
// ─────────────────────────────────────────────────────────────────────────
/// Full-width outlined button for OAuth providers (Google, Facebook, etc.).
/// Pass an SF Symbol name OR the name of an image in Assets.xcassets.
///
/// Usage:
///   SocialButton(icon: "google_icon", label: "Continue with Google") { … }
struct SocialButton: View {

    let icon: String      // asset name in Assets.xcassets (see SETUP_GUIDE.md)
    let label: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                // Try loading from Assets; fallback to SF Symbol for dev convenience
                Group {
                    if UIImage(named: icon) != nil {
                        Image(icon)
                            .resizable()
                            .scaledToFit()
                    } else {
                        // Temporary SF Symbol placeholder until real icons are added
                        Image(systemName: icon == "google_icon" ? "g.circle.fill" : "f.circle.fill")
                            .resizable()
                            .scaledToFit()
                            .foregroundColor(icon == "google_icon" ? .red : .blue)
                    }
                }
                .frame(width: 22, height: 22)

                Text(label)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(Theme.titleText)
            }
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(Color.white)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Theme.socialBorder, lineWidth: 1.5)
            )
        }
    }
}

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: OR Divider
// ─────────────────────────────────────────────────────────────────────────
/// Horizontal rule with a centered label: ── OR ──
struct DividerWithLabel: View {

    var text: String = "OR"

    var body: some View {
        HStack(spacing: 12) {
            Rectangle()
                .fill(Theme.fieldBorder)
                .frame(height: 1)

            Text(text)
                .font(.system(size: 13, weight: .regular))
                .foregroundColor(Theme.subtitleText)
                .fixedSize()

            Rectangle()
                .fill(Theme.fieldBorder)
                .frame(height: 1)
        }
    }
}

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: Auth Text Field (email / username)
// ─────────────────────────────────────────────────────────────────────────
/// Rounded text field with a leading SF Symbol icon.
///
/// Usage:
///   AuthTextField(icon: "person", placeholder: "Email", text: $email, keyboardType: .emailAddress)
struct AuthTextField: View {

    let icon: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(Theme.fieldIcon)
                .frame(width: 20)

            TextField(placeholder, text: $text)
                .keyboardType(keyboardType)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)
                .font(.system(size: 15))
                .foregroundColor(Theme.titleText)
        }
        .padding(.horizontal, 14)
        .frame(height: 52)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Theme.fieldBorder, lineWidth: 1.5)
        )
    }
}

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: Auth Secure Field (password)
// ─────────────────────────────────────────────────────────────────────────
/// Rounded password field with a leading lock icon and a show/hide toggle.
///
/// Usage:
///   AuthSecureField(placeholder: "Password", text: $password, showPassword: $showPassword)
struct AuthSecureField: View {

    let placeholder: String
    @Binding var text: String
    @Binding var showPassword: Bool

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "lock")
                .foregroundColor(Theme.fieldIcon)
                .frame(width: 20)

            // Swap between SecureField and TextField based on showPassword
            if showPassword {
                TextField(placeholder, text: $text)
                    .font(.system(size: 15))
                    .foregroundColor(Theme.titleText)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            } else {
                SecureField(placeholder, text: $text)
                    .font(.system(size: 15))
                    .foregroundColor(Theme.titleText)
            }

            // Eye toggle button
            Button {
                showPassword.toggle()
            } label: {
                Image(systemName: showPassword ? "eye.slash" : "eye")
                    .foregroundColor(Theme.fieldIcon)
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 52)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Theme.fieldBorder, lineWidth: 1.5)
        )
    }
}

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: Checkbox
// ─────────────────────────────────────────────────────────────────────────
/// Small square checkbox matching the "Remember me" / "I agree" style.
struct CheckboxView: View {

    @Binding var isChecked: Bool

    var body: some View {
        Button {
            isChecked.toggle()
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 4)
                    .stroke(Theme.fieldBorder, lineWidth: 1.5)
                    .frame(width: 18, height: 18)
                    .background(
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color.white)
                    )

                if isChecked {
                    Image(systemName: "checkmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(Theme.linkText)
                }
            }
        }
        .buttonStyle(.plain)
    }
}

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: Cookie Notice
// ─────────────────────────────────────────────────────────────────────────
/// The small cookie-policy footer shown at the bottom of both auth screens.
struct CookieNoticeView: View {
    var body: some View {
        (
            Text("This app uses cookies for analytics personalized content and ads. By using this app's services you agree to this use of cookies.  ")
                .font(.system(size: 10))
                .foregroundColor(Theme.subtitleText)
            +
            Text("Learn More")
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(Theme.linkText)
        )
        .multilineTextAlignment(.center)
        .padding(.horizontal, 24)
    }
}

// MARK: ─────────────────────────────────────────────────────────────────────
// MARK: Primary Action Button
// ─────────────────────────────────────────────────────────────────────────
/// Full-width filled button used for "Login", "Continue with Email", etc.
struct PrimaryButton: View {

    let title: String
    var isEnabled: Bool = true
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Theme.primaryButtonText)
                .frame(maxWidth: .infinity, minHeight: 52)
                .background(
                    Theme.primaryButtonBG
                        .opacity(isEnabled ? 1.0 : 0.5)
                )
                .cornerRadius(12)
        }
        .disabled(!isEnabled)
    }
}

// MARK: - Preview
#Preview {
    ScrollView {
        VStack(spacing: 20) {
            SocialButton(icon: "google_icon", label: "Continue with Google") {}
            SocialButton(icon: "facebook_icon", label: "Continue With Facebook") {}
            DividerWithLabel()
            AuthTextField(icon: "person", placeholder: "Email", text: .constant(""))
            AuthSecureField(placeholder: "Password", text: .constant(""), showPassword: .constant(false))
            PrimaryButton(title: "Login") {}
            CookieNoticeView()
        }
        .padding(24)
    }
}
