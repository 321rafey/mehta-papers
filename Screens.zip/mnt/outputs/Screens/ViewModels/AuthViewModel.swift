// AuthViewModel.swift
// Screens
//
// Handles all authentication logic.
//
// Right now every method is a STUB — it prints to the console so you can
// confirm taps are wired up correctly before connecting a real auth provider.
//
// The inline TODO blocks tell you exactly what to drop in once you've added
// the Google / Facebook SDKs via Swift Package Manager (see SETUP_GUIDE.md).

import SwiftUI
import Combine

@MainActor
final class AuthViewModel: ObservableObject {

    // MARK: - Published State

    /// Set to true after a successful login / sign-up to trigger navigation
    @Published var isAuthenticated: Bool   = false

    /// Non-nil when an error should be shown to the user
    @Published var errorMessage: String?   = nil

    /// True while a network / SDK call is in flight
    @Published var isLoading: Bool         = false

    // MARK: ─────────────────────────────────────────────────────────────────
    // MARK: Email Auth
    // ─────────────────────────────────────────────────────────────────────

    /// Sign up a new user with an email address.
    /// Extend this to ask for a password on the next screen once your backend is ready.
    func signUpWithEmail(email: String) {
        guard isValidEmail(email) else {
            errorMessage = "Please enter a valid email address."
            return
        }

        isLoading    = true
        errorMessage = nil

        // ── TODO: Replace this block with your real backend call ──────────
        //
        // Option A — Firebase Auth:
        //   import FirebaseAuth
        //   Auth.auth().createUser(withEmail: email, password: password) { result, error in
        //       self.isLoading = false
        //       if let error { self.errorMessage = error.localizedDescription; return }
        //       self.isAuthenticated = true
        //   }
        //
        // Option B — Custom REST API:
        //   var request = URLRequest(url: URL(string: "https://api.yourapp.com/register")!)
        //   request.httpMethod = "POST"
        //   request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        //   request.httpBody = try? JSONEncoder().encode(["email": email])
        //   URLSession.shared.dataTask(with: request) { data, _, error in
        //       DispatchQueue.main.async {
        //           self.isLoading = false
        //           if let error { self.errorMessage = error.localizedDescription; return }
        //           self.isAuthenticated = true
        //       }
        //   }.resume()
        // ─────────────────────────────────────────────────────────────────

        // Stub: simulate a short network delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.isLoading       = false
            self.isAuthenticated = true
            print("✅ [STUB] Sign up with email: \(email)")
        }
    }

    /// Log in an existing user with email + password.
    func loginWithEmail(email: String, password: String) {
        guard isValidEmail(email) else {
            errorMessage = "Please enter a valid email address."
            return
        }
        guard !password.isEmpty else {
            errorMessage = "Please enter your password."
            return
        }

        isLoading    = true
        errorMessage = nil

        // ── TODO: Replace this block with your real backend call ──────────
        //
        // Option A — Firebase Auth:
        //   import FirebaseAuth
        //   Auth.auth().signIn(withEmail: email, password: password) { result, error in
        //       self.isLoading = false
        //       if let error { self.errorMessage = error.localizedDescription; return }
        //       self.isAuthenticated = true
        //   }
        //
        // Option B — Custom REST API:
        //   (same pattern as signUpWithEmail above, different endpoint)
        // ─────────────────────────────────────────────────────────────────

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            self.isLoading       = false
            self.isAuthenticated = true
            print("✅ [STUB] Login with email: \(email)")
        }
    }

    // MARK: ─────────────────────────────────────────────────────────────────
    // MARK: Google Sign-In
    // ─────────────────────────────────────────────────────────────────────

    func signInWithGoogle() {
        // ── STEP 1 — Add package in Xcode ────────────────────────────────
        //   File ▸ Add Package Dependencies…
        //   URL: https://github.com/google/GoogleSignIn-iOS
        //   Add product: GoogleSignIn
        //
        // ── STEP 2 — Info.plist keys ──────────────────────────────────────
        //   GIDClientID         → your OAuth 2.0 client ID (from Google Cloud Console)
        //   CFBundleURLTypes    → add a URL scheme: com.googleusercontent.apps.YOUR_CLIENT_ID
        //
        // ── STEP 3 — Uncomment AppDelegate in ScreensApp.swift ───────────
        //   (needed to handle the OAuth redirect URL)
        //
        // ── STEP 4 — Uncomment and use the code below ─────────────────────
        //
        // import GoogleSignIn
        //
        // guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
        //       let root  = scene.windows.first?.rootViewController else { return }
        //
        // isLoading = true
        // GIDSignIn.sharedInstance.signIn(withPresenting: root) { [weak self] result, error in
        //     guard let self else { return }
        //     self.isLoading = false
        //     if let error { self.errorMessage = error.localizedDescription; return }
        //     guard let idToken = result?.user.idToken?.tokenString else { return }
        //     // Use idToken to authenticate with your backend / Firebase
        //     print("Google ID token: \(idToken)")
        //     self.isAuthenticated = true
        // }
        // ─────────────────────────────────────────────────────────────────

        print("🔵 [STUB] Google Sign-In tapped — SDK not yet connected")
    }

    // MARK: ─────────────────────────────────────────────────────────────────
    // MARK: Facebook Sign-In
    // ─────────────────────────────────────────────────────────────────────

    func signInWithFacebook() {
        // ── STEP 1 — Add package in Xcode ────────────────────────────────
        //   File ▸ Add Package Dependencies…
        //   URL: https://github.com/facebook/facebook-ios-sdk
        //   Add product: FacebookLogin
        //
        // ── STEP 2 — Info.plist keys ──────────────────────────────────────
        //   FacebookAppID         → your App ID from developers.facebook.com
        //   FacebookClientToken   → your Client Token
        //   FacebookDisplayName   → display name shown in Facebook dialogs
        //   LSApplicationQueriesSchemes → ["fbapi", "fb-messenger-share-api"]
        //   CFBundleURLTypes      → add scheme: fb + YOUR_APP_ID  (e.g. "fb123456789")
        //
        // ── STEP 3 — Initialise SDK in ScreensApp.swift ──────────────────
        //   import FacebookCore
        //   In AppDelegate.application(_:didFinishLaunchingWithOptions:):
        //     ApplicationDelegate.shared.application(application, didFinishLaunchingWithOptions: launchOptions)
        //
        // ── STEP 4 — Uncomment and use the code below ─────────────────────
        //
        // import FacebookLogin
        //
        // let manager = LoginManager()
        // isLoading   = true
        // manager.logIn(permissions: ["email", "public_profile"], from: nil) { [weak self] result, error in
        //     guard let self else { return }
        //     self.isLoading = false
        //     if let error { self.errorMessage = error.localizedDescription; return }
        //     guard let token = AccessToken.current?.tokenString else { return }
        //     // Use token to authenticate with your backend / Firebase
        //     print("Facebook token: \(token)")
        //     self.isAuthenticated = true
        // }
        // ─────────────────────────────────────────────────────────────────

        print("🔷 [STUB] Facebook Sign-In tapped — SDK not yet connected")
    }

    // MARK: ─────────────────────────────────────────────────────────────────
    // MARK: Helpers
    // ─────────────────────────────────────────────────────────────────────

    private func isValidEmail(_ email: String) -> Bool {
        let pattern = #"^[A-Z0-9a-z._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"#
        return email.range(of: pattern, options: .regularExpression) != nil
    }
}
