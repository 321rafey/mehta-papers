// Theme.swift
// Screens
//
// Central design system — all colors, gradients, and the hex Color extension.
// Change values here and every screen updates automatically.

import SwiftUI

// MARK: - Theme Namespace
enum Theme {

    // ── Background gradient ──────────────────────────────────────────────────
    /// Top of the full-screen gradient (cool light gray)
    static let gradientTop    = Color(hex: "#D8D8D8")
    /// Bottom of the full-screen gradient (warm cream / wheat)
    static let gradientBottom = Color(hex: "#EFE0B0")

    // ── Primary action button ────────────────────────────────────────────────
    /// Filled button background (warm cream — matches gradient bottom)
    static let primaryButtonBG   = Color(hex: "#F0DEAD")
    static let primaryButtonText = Color(hex: "#1A1A1A")

    // ── Typography ───────────────────────────────────────────────────────────
    static let titleText    = Color(hex: "#1A1A1A")
    static let subtitleText = Color(hex: "#6B6B6B")
    /// Warm gold — used for links ("Privacy & Policy", "Login", "Sign Up")
    static let linkText     = Color(hex: "#8B6914")

    // ── Form fields ──────────────────────────────────────────────────────────
    static let fieldBorder  = Color(hex: "#D0D0D0")
    static let fieldIcon    = Color(hex: "#AAAAAA")

    // ── Social buttons ───────────────────────────────────────────────────────
    static let socialBorder = Color(hex: "#D0D0D0")

    // ── Onboarding dot indicator ─────────────────────────────────────────────
    static let dotActive   = Color(hex: "#C8A96E")   // active page
    static let dotInactive = Color(hex: "#D0D0D0")   // other pages

    // ── Convenience: full-screen gradient ───────────────────────────────────
    static var appGradient: LinearGradient {
        LinearGradient(
            colors: [gradientTop, gradientBottom],
            startPoint: .top,
            endPoint: .bottom
        )
    }
}

// MARK: - Hex Color Initializer
// Lets us write Color(hex: "#D8D8D8") anywhere in the project.
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:  (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:  (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:  (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red:     Double(r) / 255,
            green:   Double(g) / 255,
            blue:    Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
