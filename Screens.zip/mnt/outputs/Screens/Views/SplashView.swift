// SplashView.swift
// Screens
//
// First screen the user sees — full-screen gradient with the animated logo.
// Automatically navigates to the Onboarding screen after ~2 seconds.

import SwiftUI

struct SplashView: View {

    @Binding var currentScreen: AppScreen

    // Animation state
    @State private var logoScale:   CGFloat = 0.55
    @State private var logoOpacity: Double  = 0.0

    var body: some View {
        ZStack {
            // ── Full-screen gradient ─────────────────────────────────────
            Theme.appGradient
                .ignoresSafeArea()

            // ── Centered logo ────────────────────────────────────────────
            LogoView(size: 110)
                .scaleEffect(logoScale)
                .opacity(logoOpacity)
        }
        .onAppear {
            animateLogo()
        }
    }

    // MARK: - Helpers

    private func animateLogo() {
        // Spring-in animation when view appears
        withAnimation(.spring(response: 0.55, dampingFraction: 0.68, blendDuration: 0)) {
            logoScale   = 1.0
            logoOpacity = 1.0
        }

        // Navigate to onboarding after a short pause
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            currentScreen = .onboarding
        }
    }
}

// MARK: - Preview
#Preview {
    SplashView(currentScreen: .constant(.splash))
}
