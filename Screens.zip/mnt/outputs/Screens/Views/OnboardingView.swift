// OnboardingView.swift
// Screens
//
// Swipeable onboarding carousel matching the screenshot:
//  • Logo + gradient background fills the top portion
//  • Text panel below the logo
//  • Custom dot indicator (animates width on active dot)
//  • "Sign Up" (outlined) and "Login" (filled) buttons pinned to the bottom

import SwiftUI

// MARK: - Data Model
struct OnboardingPage: Identifiable {
    let id  = UUID()
    let title: String
    let description: String
}

// MARK: - Onboarding View
struct OnboardingView: View {

    @Binding var currentScreen: AppScreen

    // Four pages — matching the four dots visible in the screenshot
    private let pages: [OnboardingPage] = [
        OnboardingPage(
            title: "Streamline your ordering process!",
            description: "Buyers can place orders anytime without calling or visiting, reducing manual order-taking errors."
        ),
        OnboardingPage(
            title: "Track orders in real time",
            description: "Get live updates on every order from placement to delivery, all from one dashboard."
        ),
        OnboardingPage(
            title: "Manage your catalog easily",
            description: "Add, edit, or remove products instantly so buyers always see accurate stock and pricing."
        ),
        OnboardingPage(
            title: "Grow your business faster",
            description: "Built-in analytics surface trends and insights that help you make smarter decisions."
        ),
    ]

    @State private var selectedPage: Int = 0

    var body: some View {
        ZStack(alignment: .bottom) {

            // ── Page carousel ────────────────────────────────────────────
            TabView(selection: $selectedPage) {
                ForEach(Array(pages.enumerated()), id: \.element.id) { index, page in
                    OnboardingCardView(page: page)
                        .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never)) // hide default dots
            .ignoresSafeArea()

            // ── Bottom overlay (dots + buttons) ──────────────────────────
            VStack(spacing: 0) {

                Spacer()

                // Dot indicators
                HStack(spacing: 6) {
                    ForEach(0 ..< pages.count, id: \.self) { i in
                        Capsule()
                            .fill(i == selectedPage ? Theme.dotActive : Theme.dotInactive)
                            // Active dot is wider
                            .frame(width: i == selectedPage ? 22 : 8, height: 8)
                            .animation(.easeInOut(duration: 0.25), value: selectedPage)
                    }
                }
                .padding(.bottom, 28)

                // Sign Up + Login buttons
                HStack(spacing: 12) {

                    // Sign Up — outlined style
                    Button {
                        currentScreen = .signUp
                    } label: {
                        Text("Sign Up")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(Theme.titleText)
                            .frame(maxWidth: .infinity, minHeight: 52)
                            .background(Color.white)
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Theme.fieldBorder, lineWidth: 1.5)
                            )
                    }

                    // Login — filled style
                    Button {
                        currentScreen = .login
                    } label: {
                        Text("Login")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(Theme.primaryButtonText)
                            .frame(maxWidth: .infinity, minHeight: 52)
                            .background(Theme.primaryButtonBG)
                            .cornerRadius(12)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 44)
            }
        }
    }
}

// MARK: - Individual Onboarding Card
struct OnboardingCardView: View {

    let page: OnboardingPage

    var body: some View {
        ZStack {
            // Same gradient as splash
            Theme.appGradient.ignoresSafeArea()

            VStack(alignment: .leading, spacing: 0) {

                Spacer()

                // Logo centered in the upper two-thirds
                HStack {
                    Spacer()
                    LogoView(size: 110)
                    Spacer()
                }
                .padding(.bottom, 52)

                // Text content
                VStack(alignment: .leading, spacing: 10) {

                    Text(page.title)
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(Theme.titleText)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)

                    Text(page.description)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Theme.subtitleText)
                        .multilineTextAlignment(.leading)
                        .lineSpacing(4)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 28)

                // Reserve space for the bottom buttons panel
                Spacer().frame(height: 170)
            }
        }
    }
}

// MARK: - Preview
#Preview {
    OnboardingView(currentScreen: .constant(.onboarding))
}
