// SignUpView.swift
// Screens
//
// "Get your free account" screen — matches the screenshot exactly:
//  • Google + Facebook OAuth buttons
//  • OR divider
//  • Email text field
//  • "I Agree with Privacy & Policy" checkbox
//  • "Continue with Email" primary button
//  • "Already have an account? Login" footer link
//  • Cookie notice

import SwiftUI

struct SignUpView: View {

    @Binding var currentScreen: AppScreen

    // ViewModel handles auth calls (stubs for now — see AuthViewModel.swift)
    @StateObject private var authVM = AuthViewModel()

    // Form state
    @State private var email          = ""
    @State private var agreedToPolicy = false
    @State private var showError      = false

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {

                    // ── Title ────────────────────────────────────────────
                    Text("Get your free account")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(Theme.titleText)
                        .padding(.top, 72)
                        .padding(.horizontal, 24)
                        .padding(.bottom, 36)

                    // ── Social buttons ───────────────────────────────────
                    VStack(spacing: 12) {
                        SocialButton(icon: "google_icon", label: "Continue with google") {
                            authVM.signInWithGoogle()
                        }
                        SocialButton(icon: "facebook_icon", label: "Continue With Facebook") {
                            authVM.signInWithFacebook()
                        }
                    }
                    .padding(.horizontal, 24)

                    // ── OR divider ───────────────────────────────────────
                    DividerWithLabel()
                        .padding(.horizontal, 24)
                        .padding(.vertical, 24)

                    // ── Email field ──────────────────────────────────────
                    AuthTextField(
                        icon: "person",
                        placeholder: "Email",
                        text: $email,
                        keyboardType: .emailAddress
                    )
                    .padding(.horizontal, 24)

                    // ── Privacy & Policy checkbox ────────────────────────
                    HStack(alignment: .center, spacing: 8) {
                        CheckboxView(isChecked: $agreedToPolicy)

                        // Styled "I Agree with Privacy & Policy" text
                        (
                            Text("I Agree with ")
                                .font(.system(size: 13))
                                .foregroundColor(Theme.subtitleText)
                            + Text("Privacy")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Theme.linkText)
                            + Text(" & ")
                                .font(.system(size: 13))
                                .foregroundColor(Theme.subtitleText)
                            + Text("Policy")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(Theme.linkText)
                        )
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 16)

                    // ── Error message (shown only when needed) ───────────
                    if showError {
                        Text(authVM.errorMessage ?? "Please fill all required fields.")
                            .font(.system(size: 12))
                            .foregroundColor(.red)
                            .padding(.horizontal, 24)
                            .padding(.top, 8)
                    }

                    // ── Continue with Email button ───────────────────────
                    PrimaryButton(
                        title: "Continue with Email",
                        isEnabled: agreedToPolicy && !email.isEmpty
                    ) {
                        attemptSignUp()
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 28)

                    // ── "Already have an account? Login" link ────────────
                    HStack(spacing: 0) {
                        Spacer()
                        Text("Already have an account? ")
                            .font(.system(size: 14))
                            .foregroundColor(Theme.subtitleText)
                        Button("Login") {
                            currentScreen = .login
                        }
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Theme.linkText)
                        Spacer()
                    }
                    .padding(.top, 22)

                    // ── Cookie notice ────────────────────────────────────
                    CookieNoticeView()
                        .padding(.top, 20)

                    Spacer(minLength: 44)
                }
            }

            // ── Loading overlay ──────────────────────────────────────────
            if authVM.isLoading {
                Color.black.opacity(0.25).ignoresSafeArea()
                ProgressView()
                    .scaleEffect(1.4)
                    .tint(.white)
            }
        }
        // Show errors surfaced by the ViewModel
        .onChange(of: authVM.errorMessage) { msg in
            showError = msg != nil
        }
    }

    // MARK: - Helpers

    private func attemptSignUp() {
        guard agreedToPolicy else { return }
        showError = false
        authVM.signUpWithEmail(email: email)
    }
}

// MARK: - Preview
#Preview {
    SignUpView(currentScreen: .constant(.signUp))
}
