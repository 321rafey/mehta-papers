// LoginView.swift
// Screens
//
// "Log in to App" screen — matches the screenshot exactly:
//  • Email + Password fields
//  • "Remember me" checkbox + "Forgot password?" link
//  • Login primary button
//  • OR divider
//  • Google + Facebook OAuth buttons
//  • "Don't have an account? Sign Up" footer link
//  • Cookie notice

import SwiftUI

struct LoginView: View {

    @Binding var currentScreen: AppScreen

    // ViewModel handles auth calls (stubs for now — see AuthViewModel.swift)
    @StateObject private var authVM = AuthViewModel()

    // Form state
    @State private var email        = ""
    @State private var password     = ""
    @State private var rememberMe   = false
    @State private var showPassword = false
    @State private var showError    = false

    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {

                    // ── Title ────────────────────────────────────────────
                    Text("Log in to App")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(Theme.titleText)
                        .padding(.top, 72)
                        .padding(.horizontal, 24)
                        .padding(.bottom, 36)

                    // ── Email field ──────────────────────────────────────
                    AuthTextField(
                        icon: "person",
                        placeholder: "Email",
                        text: $email,
                        keyboardType: .emailAddress
                    )
                    .padding(.horizontal, 24)

                    // ── Password field ───────────────────────────────────
                    AuthSecureField(
                        placeholder: "Password",
                        text: $password,
                        showPassword: $showPassword
                    )
                    .padding(.horizontal, 24)
                    .padding(.top, 12)

                    // ── Remember me + Forgot password ────────────────────
                    HStack {
                        HStack(spacing: 8) {
                            CheckboxView(isChecked: $rememberMe)
                            Text("Remember me")
                                .font(.system(size: 13))
                                .foregroundColor(Theme.subtitleText)
                        }

                        Spacer()

                        Button("Forgot password?") {
                            // TODO: Navigate to ForgotPasswordView
                            // currentScreen = .forgotPassword
                        }
                        .font(.system(size: 13))
                        .foregroundColor(Theme.subtitleText)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 14)

                    // ── Error message ────────────────────────────────────
                    if showError {
                        Text(authVM.errorMessage ?? "Please fill in all fields.")
                            .font(.system(size: 12))
                            .foregroundColor(.red)
                            .padding(.horizontal, 24)
                            .padding(.top, 8)
                    }

                    // ── Login button ─────────────────────────────────────
                    PrimaryButton(
                        title: "Login",
                        isEnabled: !email.isEmpty && !password.isEmpty
                    ) {
                        attemptLogin()
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 24)

                    // ── OR divider ───────────────────────────────────────
                    DividerWithLabel()
                        .padding(.horizontal, 24)
                        .padding(.vertical, 20)

                    // ── Social buttons ───────────────────────────────────
                    VStack(spacing: 12) {
                        SocialButton(icon: "google_icon", label: "Continue with google") {
                            authVM.signInWithGoogle()
                        }
                        SocialButton(icon: "facebook_icon", label: "Continue With Facebook") {
                            authVM.signInWithFacebook()
                        }
                    }
                    .padding(.horizontal, 24)

                    // ── "Don't have an account? Sign Up" link ────────────
                    HStack(spacing: 0) {
                        Spacer()
                        Text("Don't have an account? ")
                            .font(.system(size: 14))
                            .foregroundColor(Theme.subtitleText)
                        Button("Sign Up") {
                            currentScreen = .signUp
                        }
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Theme.linkText)
                        Spacer()
                    }
                    .padding(.top, 20)

                    // ── Cookie notice ────────────────────────────────────
                    CookieNoticeView()
                        .padding(.top, 20)

                    Spacer(minLength: 44)
                }
            }

            // ── Loading overlay ──────────────────────────────────────────
            if authVM.isLoading {
                Color.black.opacity(0.25).ignoresSafeArea()
                ProgressView()
                    .scaleEffect(1.4)
                    .tint(.white)
            }
        }
        .onChange(of: authVM.errorMessage) { msg in
            showError = msg != nil
        }
    }

    // MARK: - Helpers

    private func attemptLogin() {
        showError = false
        authVM.loginWithEmail(email: email, password: password)
    }
}

// MARK: - Preview
#Preview {
    LoginView(currentScreen: .constant(.login))
}
